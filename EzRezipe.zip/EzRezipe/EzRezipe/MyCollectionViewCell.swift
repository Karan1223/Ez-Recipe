//
//  MyCollectionViewCell.swift
//  EzRezipe
//
//  Created by Richu Thankachan on 2023-04-19.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell
{
    
  
    @IBOutlet weak var btn1: UIButton!
    
}
